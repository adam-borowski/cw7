﻿namespace AuthenticationSampleWebApp.Controllers
{
    internal class JwtSecurityTokenHander
    {
        public JwtSecurityTokenHander()
        {
        }
    }
}